import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'home_page.dart';

class ContactPage extends StatefulWidget {
  const ContactPage({super.key});

  @override
  State<ContactPage> createState() => _ContactPageState();
}

class _ContactPageState extends State<ContactPage> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<Color?> _color1;
  late Animation<Color?> _color2;

  @override
  void initState() {
    super.initState();

    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 5))
      ..repeat(reverse: true);

    _color1 = ColorTween(begin: Colors.deepPurple, end: Colors.purpleAccent).animate(_controller);
    _color2 = ColorTween(begin: Colors.pinkAccent, end: Colors.blueAccent).animate(_controller);
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  Future<void> _launchUrl(String url) async {
    final Uri uri = Uri.parse(url);
    if (!await launchUrl(uri, mode: LaunchMode.externalApplication)) {
      throw Exception('Could not launch $url');
    }
  }

  @override
  Widget build(BuildContext context) {
    return AnimatedBuilder(
      animation: _controller,
      builder: (context, _) {
        return Scaffold(
          appBar: AppBar(title: const Text('Contact Page')),
          drawer: const AppDrawer(),
          body: Container(
            decoration: BoxDecoration(
              gradient: LinearGradient(
                colors: [_color1.value ?? Colors.deepPurple, _color2.value ?? Colors.blueAccent],
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
              ),
            ),
            child: Center(
              child: Padding(
                padding: const EdgeInsets.all(24),
                child: Column(
                  mainAxisAlignment: MainAxisAlignment.center,
                  children: [
                    const Icon(Icons.contact_mail, color: Colors.white, size: 80),
                    const SizedBox(height: 20),
                    const Text(
                      'تواصل معي 📞',
                      style: TextStyle(
                        fontSize: 30,
                        color: Colors.white,
                        fontWeight: FontWeight.bold,
                        shadows: [Shadow(blurRadius: 10, color: Colors.black26, offset: Offset(2, 2))],
                      ),
                    ),
                    const SizedBox(height: 30),
                    GestureDetector(
                      onTap: () => _launchUrl('tel:01090246130'),
                      child: const Text('📱 01090246130',
                          style: TextStyle(fontSize: 22, color: Colors.white70)),
                    ),
                    const SizedBox(height: 10),
                    GestureDetector(
                      onTap: () => _launchUrl('mailto:rdam1116@gmail.com'),
                      child: const Text('📧 rdam1116@gmail.com',
                          style: TextStyle(fontSize: 22, color: Colors.white70)),
                    ),
                    const SizedBox(height: 10),
                    GestureDetector(
                      onTap: () => _launchUrl('https://www.linkedin.com/in/mohamed-reda-537692242'),
                      child: const Text(
                        '🔗 linkedin.com/in/mohamed-reda-537692242',
                        style: TextStyle(
                          fontSize: 22,
                          color: Colors.white70,
                          decoration: TextDecoration.underline,
                        ),
                      ),
                    ),
                    const SizedBox(height: 40),
                    ElevatedButton.icon(
                      onPressed: () => _launchUrl('mailto:rdam1116@gmail.com'),
                      icon: const Icon(Icons.send),
                      label: const Text('إرسال رسالة'),
                      style: ElevatedButton.styleFrom(
                        backgroundColor: Colors.white,
                        foregroundColor: Colors.deepPurple,
                        padding: const EdgeInsets.symmetric(horizontal: 25, vertical: 14),
                        textStyle: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
                        shadowColor: Colors.black54,
                        elevation: 8,
                      ),
                    ),
                  ],
                ),
              ),
            ),
          ),
        );
      },
    );
  }
}
